<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/index.css">
    <title>学生列表</title>
</head>
<body>
    <h1>学生列表</h1>
    <form action="/list" method="get">
        姓名 : <input type="text" name="key" value="<?php echo e($gets['key']??''); ?>">
        性别 : <input type="radio" name="sex" value="男" <?php echo e(($gets['sex']??'')=='男'?'checked':''); ?>> 男
        <input type="radio" name="sex" value="女" <?php echo e(($gets['sex']??'')=='女'?'checked':''); ?>> 女
        <br>
        专业 :
        <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="checkbox" name="mjs[]" value="<?php echo e($v['id']); ?>" <?php echo e(in_array($v['id'],($gets['mjs']??[]))?'checked':''); ?>> <?php echo e($v['major']); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <button>搜索</button>
    </form>
    <a href="/add">添加</a>
    <table border="1">
        <tr>
            <th>学号</th>
            <th>姓名</th>
            <th>头像</th>
            <th>生日</th>
            <th>性别</th>
            <th>年龄</th>
            <th>专业</th>
            <th>操作</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td><?php echo e($v['name']); ?></td>
            <td>
                <img src="/uploads/<?php echo e($v['headimg']); ?>" alt="" width="50" height="50">
            </td>
            <td><?php echo e($v['birthday']); ?></td>
            <td><?php echo e($v['sex']); ?></td>
            <td><?php echo e($v['age']); ?></td>
            <td><?php echo e($v['major']); ?></td>
            <td>
                
                
                <a href="/del/<?php echo e($v['id']); ?>?<?php echo e(http_build_query($gets)); ?>">删除</a>
                <a href="">修改</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <th colspan="8">暂无数据</th>
            </tr>
        <?php endif; ?>
        <tr>
            <td colspan="8" style="text-align: center">
                
                
                <?php echo e($list->withQueryString()->links()); ?>

            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\phpstudy_pro\WWW\l-39\resources\views/student/list.blade.php ENDPATH**/ ?>