<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>首页</h1>
    
    
    <?php echo e($name); ?>

    
    <?php echo $name; ?>

    <?php echo e($sex); ?>

    <?php echo e($age); ?>

    <hr>
    <?php echo e(md5($age)); ?> <br>
    <?php echo e(date("Y-m-d h:i:s",time())); ?>

    <hr>
    <?php if($point >= 90): ?>
        优秀
    <?php elseif($point >= 80): ?>
        良好
    <?php elseif($point >= 60): ?>
        及格
    <?php else: ?>
        不及格
    <?php endif; ?> |

    <?php if(isset($abc)): ?>
        abc存在
    <?php else: ?>
        abc不存在
    <?php endif; ?> |

    <?php if(empty($abc)): ?>
        abc为空
    <?php endif; ?> |

    <?php echo e($point>=60?'及格':'不及格'); ?> |
    <?php echo e($abc??'默认值'); ?>

    <hr>
    <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($v['id']); ?> - <?php echo e($v['name']); ?> - <?php echo e($v['age']); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <?php $__empty_1 = true; $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo e($v['id']); ?> - <?php echo e($v['name']); ?> - <?php echo e($v['age']); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        没有值
    <?php endif; ?>
    <hr>
    <?php for($i=1;$i<=10;$i++): ?>
        <?php echo e($i); ?>

    <?php endfor; ?>
    <hr>
    <?php
        echo 123456;
    ?>
</body>
</html>
<?php /**PATH D:\phpstudy_pro\WWW\l-39\resources\views/ding/list.blade.php ENDPATH**/ ?>