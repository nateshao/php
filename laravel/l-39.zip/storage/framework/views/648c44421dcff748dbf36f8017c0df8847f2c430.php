<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>用户登录</title>
</head>
<body>
    <h1>登录</h1>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="/lact" method="post">
        <?php echo csrf_field(); ?>
        用户名 : <input type="text" name="user"> <br>
        密码 : <input type="password" name="pwd"> <br>
        验证码 : <input type="text" name="code" >
        <img src="<?php echo e(captcha_src("math")); ?>" alt=""> <br>
        <button>登录</button>
    </form>
</body>
</html>
<?php /**PATH D:\phpstudy_pro\WWW\l-39\resources\views/login/index.blade.php ENDPATH**/ ?>