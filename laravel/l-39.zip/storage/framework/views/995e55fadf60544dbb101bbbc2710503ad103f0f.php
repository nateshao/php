<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>添加</title>
</head>
<body>
<h1>学生添加</h1>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="/save" method="post" enctype="multipart/form-data">
    
    <?php echo csrf_field(); ?>
    姓名 : <input type="text" name="name"> <br>
    头像 : <input type="file" name="logo"> <br>
    性别 :
    <input type="radio" name="sex" value="男"> 男
    <input type="radio" name="sex" value="女"> 女 <br>
    年龄 : <input type="number" name="age"> <br>
    生日 : <input type="date" name="birthday"> <br>
    专业 :
    <select name="m_id" id="">
        <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($v['id']); ?>"><?php echo e($v['major']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select> <br>
    <button>添加</button>
</form>
</body>
</html>
<?php /**PATH D:\phpstudy_pro\WWW\l-39\resources\views/student/add.blade.php ENDPATH**/ ?>